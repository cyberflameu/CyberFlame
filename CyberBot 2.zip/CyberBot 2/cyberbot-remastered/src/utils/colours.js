/*
 * Aaron Lowe 2019
 * Constants for colours used in discord embedded messages.
 */

export const red = 0xE74C3C
export const orange = 0xF39C12
export const yellow = 0xF1C40F
export const green = 0x2ECC71
export const blue = 0x3498DB
export const grey = 0x34495E
export const purple = 0x9932CC
