/*
 * Aaron Lowe 2019
 * List of statuses for the bot to use in the sidebar.
 */

export const activities = [
  'with the / command.',
  'Error occured while displaying this message.',
  'Error 404',
  'Minceraft',
  'node.js encountered an error',
  'uncaughtException',
  'SOS',
  'Creeper',
  'Mining away',
  'Storm Area 51',
  'Im watching you',
  'yeah...',
  'with you, my master.',
  'on a Christian Minecraft Server.',
  'et ur toat',
  'lmfao',
  'owo',
  'twt',
  'ligma',
  'i will kill u so hard u will die to death.'
]
